#!/usr/bin/env node
/**
 * Gateway for Extension 3333 (English) - UDP Transport
 * Copied from conf-server-phase1.js pattern
 * Sends audio to STTTTSserver via UDP (port 6120)
 */
const dgram = require("dgram");
const fs = require("fs");

const CONFIG = {
  extensionId: "3333",
  fromAsteriskPort: 4020,        // Receive RTP from Asterisk
  toAsteriskPort: 4021,          // Send RTP to Asterisk
  toServerPort: 6120,            // Send PCM to STTTTSserver UDP
  fromServerPort: 6121,          // Receive translated PCM from STTTTSserver
  serverHost: "127.0.0.1",
  language: "en",
  logFile: "/tmp/gateway-3333-udp.log"
};

const logStream = fs.createWriteStream(CONFIG.logFile, { flags: "a" });
function log(message) {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] [Gateway-3333-UDP] ${message}\n`;
  console.log(logMessage.trim());
  logStream.write(logMessage);
}

let rtpState = {
  ssrc: null,
  sequenceNumber: null,
  timestamp: null,
  payloadType: null,
  lastAsteriskAddress: null,
  lastAsteriskPort: null,
  initialized: false
};

let stats = {
  fromAsteriskPackets: 0,
  toServerPackets: 0,
  fromServerPackets: 0,
  toAsteriskPackets: 0,
  startTime: Date.now()
};

const fromAsteriskSocket = dgram.createSocket("udp4");
const toAsteriskSocket = dgram.createSocket("udp4");
const toServerSocket = dgram.createSocket("udp4");
const fromServerSocket = dgram.createSocket("udp4");

/**
 * Parse RTP header
 */
function parseRTPHeader(buffer) {
  if (buffer.length < 12) return null;
  return {
    version: (buffer[0] >> 6) & 0x03,
    padding: (buffer[0] >> 5) & 0x01,
    extension: (buffer[0] >> 4) & 0x01,
    csrcCount: buffer[0] & 0x0F,
    marker: (buffer[1] >> 7) & 0x01,
    payloadType: buffer[1] & 0x7F,
    sequenceNumber: buffer.readUInt16BE(2),
    timestamp: buffer.readUInt32BE(4),
    ssrc: buffer.readUInt32BE(8)
  };
}

/**
 * Create RTP header for outgoing packets to Asterisk
 */
function createRTPHeader() {
  if (!rtpState.initialized) {
    log("ERROR: Cannot create RTP header - session not initialized");
    return null;
  }
  const header = Buffer.alloc(12);
  header[0] = 0x80;
  header[1] = rtpState.payloadType;
  header.writeUInt16BE(rtpState.sequenceNumber, 2);
  rtpState.sequenceNumber = (rtpState.sequenceNumber + 1) % 65536;
  header.writeUInt32BE(rtpState.timestamp, 4);
  rtpState.timestamp = (rtpState.timestamp + 320) % 0x100000000;
  header.writeUInt32BE(rtpState.ssrc, 8);
  return header;
}

/**
 * Send PCM audio back to Asterisk as RTP
 */
function sendPCMToAsterisk(pcmData) {
  if (!rtpState.lastAsteriskAddress || !rtpState.lastAsteriskPort) {
    return;
  }
  const rtpHeader = createRTPHeader();
  if (!rtpHeader) return;
  const rtpPacket = Buffer.concat([rtpHeader, pcmData]);
  toAsteriskSocket.send(rtpPacket, rtpState.lastAsteriskPort, rtpState.lastAsteriskAddress, (err) => {
    if (err) log(`Error sending to Asterisk: ${err.message}`);
    else stats.toAsteriskPackets++;
  });
}

/**
 * Receive RTP from Asterisk
 * Extract PCM and forward to STTTTSserver via UDP
 */
fromAsteriskSocket.on("message", (msg, rinfo) => {
  stats.fromAsteriskPackets++;
  const header = parseRTPHeader(msg);
  if (!header) return;

  // Learn RTP parameters from first packet
  if (!rtpState.initialized) {
    rtpState.ssrc = header.ssrc;
    rtpState.sequenceNumber = header.sequenceNumber;
    rtpState.timestamp = header.timestamp;
    rtpState.payloadType = header.payloadType;
    rtpState.lastAsteriskAddress = rinfo.address;
    rtpState.lastAsteriskPort = rinfo.port;
    rtpState.initialized = true;
    log(`✓ RTP session initialized: SSRC=${rtpState.ssrc}, PT=${rtpState.payloadType}`);
  } else {
    rtpState.lastAsteriskAddress = rinfo.address;
    rtpState.lastAsteriskPort = rinfo.port;
  }

  // Extract PCM payload
  let headerSize = 12 + (header.csrcCount * 4);
  if (header.extension && msg.length >= headerSize + 4) {
    const extensionLength = msg.readUInt16BE(headerSize + 2);
    headerSize += 4 + (extensionLength * 4);
  }

  const pcmPayload = msg.slice(headerSize);

  // Forward PCM to STTTTSserver via UDP (immediate, no buffering)
  toServerSocket.send(pcmPayload, CONFIG.toServerPort, CONFIG.serverHost, (err) => {
    if (err) log(`ERROR sending to STTTTSserver: ${err.message}`);
    else stats.toServerPackets++;
  });
});

/**
 * Receive translated PCM from STTTTSserver via UDP
 */
fromServerSocket.on("message", (msg, rinfo) => {
  stats.fromServerPackets++;
  sendPCMToAsterisk(msg);
});

// Bind UDP sockets
fromAsteriskSocket.bind(CONFIG.fromAsteriskPort, () => {
  log(`✓ Listening for Asterisk RTP on UDP ${CONFIG.fromAsteriskPort}`);
});

toAsteriskSocket.bind(CONFIG.toAsteriskPort, () => {
  log(`✓ Ready to send RTP to Asterisk via UDP ${CONFIG.toAsteriskPort}`);
});

fromServerSocket.bind(CONFIG.fromServerPort, () => {
  log(`✓ Listening for translated PCM from STTTTSserver on UDP ${CONFIG.fromServerPort}`);
});

// Stats logging every 30 seconds
setInterval(() => {
  const uptime = Math.floor((Date.now() - stats.startTime) / 1000);
  log(`Stats: Uptime=${uptime}s, RX_Asterisk=${stats.fromAsteriskPackets}, TX_Server=${stats.toServerPackets}, RX_Server=${stats.fromServerPackets}, TX_Asterisk=${stats.toAsteriskPackets}`);
}, 30000);

log("Gateway-3333-UDP started - Direct UDP transport to STTTTSserver");
