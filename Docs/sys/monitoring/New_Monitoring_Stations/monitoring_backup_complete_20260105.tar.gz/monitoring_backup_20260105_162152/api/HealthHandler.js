/**
 * Health Status Handler for Monitoring System
 */

async function handleHealthStatus(req, res) {
  try {
    const startTime = Date.now();
    const status = {
      isRunning: true,
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      counters: {
        inserts: 0,
        errors: 0,
        activeTraces: 0,
        scheduledUpdates: 0
      },
      database: {
        connected: false,
        poolSize: 0,
        activeConnections: 0
      },
      bucketScheduler: {
        isRunning: false,
        lastTick: null
      },
      version: '1.0.0'
    };

    // Check database connectivity
    if (this.db && this.db.pool) {
      try {
        const result = await this.db.pool.query('SELECT 1');
        status.database.connected = true;
        status.database.poolSize = this.db.pool.totalCount || 0;
        status.database.activeConnections = this.db.pool.waitingCount || 0;
        
        // Get counters from database
        const traceCount = await this.db.pool.query(
          "SELECT COUNT(*) as count FROM traces WHERE ended_at IS NULL"
        );
        status.counters.activeTraces = parseInt(traceCount.rows[0].count || 0);
        
        const updateCount = await this.db.pool.query(
          "SELECT COUNT(*) as count FROM scheduled_knob_updates WHERE status = 'pending'"
        );
        status.counters.scheduledUpdates = parseInt(updateCount.rows[0].count || 0);
        
      } catch (dbError) {
        status.database.connected = false;
        status.database.error = dbError.message;
      }
    }

    // Check BucketScheduler status
    if (this.bucketScheduler) {
      status.bucketScheduler.isRunning = this.bucketScheduler.isRunning || false;
      status.bucketScheduler.lastTick = this.bucketScheduler.lastTickTime || null;
    }

    // Get aggregator metrics if available
    if (this.aggregator) {
      status.counters.inserts = this.aggregator.stats?.totalInserts || 0;
      status.counters.errors = this.aggregator.stats?.totalErrors || 0;
    }

    // Calculate response time
    status.responseTimeMs = Date.now() - startTime;

    res.json({
      success: true,
      ...status
    });

  } catch (error) {
    console.error('[OptimizerAPI] Health status error:', error);
    res.status(500).json({
      success: false,
      isRunning: true,
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

module.exports = handleHealthStatus;
