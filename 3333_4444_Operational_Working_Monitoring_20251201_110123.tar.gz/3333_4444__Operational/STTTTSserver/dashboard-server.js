/**
 * Audio Quality Monitoring Dashboard Server
 * 
 * Provides real-time visualization of all 8 monitoring stations
 * Integrates with: LogStreamManager, WAVRecorder, BaseStation
 * Port: 3020 (configurable)
 */

const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const path = require('path');

// Import our tested modules
const BufferConfigLoader = require('./buffer-config-loader');
const BufferMonitorService = require('./buffer-monitor-service');
const LogStreamManager = require('./modules/log-stream-manager');
const WAVRecorder = require('./modules/wav-recorder');
const BaseStation = require('./stations/base-station');

class DashboardServer {
  constructor(port = 3020) {
    this.port = port;
    this.app = express();
    this.server = http.createServer(this.app);
    this.io = socketIO(this.server);
    
    // Initialize our modules
    this.configLoader = BufferConfigLoader;
    this.monitor = new BufferMonitorService(this.configLoader);
    this.logger = new LogStreamManager('./logs');
    this.recorder = new WAVRecorder('./recordings');
    
    // Station instances
    this.stations = new Map();
    
    // Setup routes and socket handlers
    this.setupRoutes();
    this.setupSocketHandlers();
  }

  setupRoutes() {
    
    // Main dashboard page (MUST be before static middleware)
    // Main dashboard page
    this.app.get('/', (req, res) => {
      res.sendFile(path.join(__dirname, 'public', 'audio-quality-dashboard.html'));
    
    // Legacy dashboard route (for backward compatibility)
    this.app.get('/dashboard.html', (req, res) => {
      res.sendFile(path.join(__dirname, 'public', 'dashboard-single.html'));
    });
    
    // Serve static files (AFTER specific routes to prevent index.html override)
    this.app.use(express.static('public'));
    });
    
    // API: Get all station metrics
    this.app.get('/api/stations', (req, res) => {
      const stationData = [];
      for (const [id, station] of this.stations) {
        stationData.push(station.getMetrics());
      }
      res.json(stationData);
    });
    
    // API: Get specific station metrics
    this.app.get('/api/stations/:id', (req, res) => {
      const station = this.stations.get(req.params.id);
      if (station) {
        res.json(station.getMetrics());
      } else {
        res.status(404).json({ error: 'Station not found' });
      }
    });
    
    // API: Get LOG status
    this.app.get('/api/logs', (req, res) => {
      const activeStations = this.logger.getActiveStations();
      const stats = {};
      for (const stationId of activeStations) {
        stats[stationId] = this.logger.getStats(stationId);
      }
      res.json(stats);
    });
    
    // API: Get WAV recordings
    this.app.get('/api/recordings', (req, res) => {
      const recordings = this.recorder.listRecordings();
      res.json(recordings);
    });
    
    // API: Get active recordings status
    this.app.get('/api/recordings/active', (req, res) => {
      const active = this.recorder.getActiveRecordings();
      res.json(active);
    });
    
    // API: Update station config
    this.app.post('/api/stations/:id/config', express.json(), (req, res) => {
      const station = this.stations.get(req.params.id);
      if (station) {
        station.updateConfig(req.body);
        res.json({ success: true, config: req.body });
      } else {
        res.status(404).json({ error: 'Station not found' });
      }
    });
    
    // API: Toggle LOG for station
    this.app.post('/api/stations/:id/log/:action', async (req, res) => {
      const { id, action } = req.params;
      try {
        if (action === 'start') {
          await this.logger.startStream(id, {
            types: req.body?.types || ['metrics', 'events'],
            format: req.body?.format || 'json'
          });
          res.json({ success: true, message: 'Logging started' });
        } else if (action === 'stop') {
          const files = await this.logger.stopStream(id);
          res.json({ success: true, files });
        } else {
          res.status(400).json({ error: 'Invalid action' });
        }
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });
    
    // API: Toggle WAV recording for station
    this.app.post('/api/stations/:id/record/:action', async (req, res) => {
      const { id, action } = req.params;
      try {
        if (action === 'start') {
          const filepath = await this.recorder.startRecording(id, {
            sampleRate: req.body?.sampleRate || 16000,
            channels: req.body?.channels || 1,
            maxDurationSec: req.body?.maxDurationSec || 300
          });
          res.json({ success: true, filepath });
        } else if (action === 'stop') {
          const result = await this.recorder.stopRecording(id);
          res.json({ success: true, result });
        } else {
          res.status(400).json({ error: 'Invalid action' });
        }
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });
  }

  setupSocketHandlers() {
    this.io.on('connection', (socket) => {
      console.log('[Dashboard] Client connected:', socket.id);
      
      // Send initial data
      this.sendAllStationData(socket);
      
      // Handle disconnection
      socket.on('disconnect', () => {
        console.log('[Dashboard] Client disconnected:', socket.id);
      });
      
      // Handle config changes
      socket.on('updateConfig', (data) => {
        const { stationId, config } = data;
        const station = this.stations.get(stationId);
        if (station) {
          station.updateConfig(config);
          this.io.emit('configUpdated', { stationId, config });
        }
      });
    });
    
    // Broadcast metrics every second
    setInterval(() => {
      this.broadcastMetrics();
    }, 1000);
  }

  sendAllStationData(socket) {
    const data = {
      stations: [],
      logs: {},
      recordings: {
        active: this.recorder.getActiveRecordings(),
        files: this.recorder.listRecordings()
      }
    };
    
    for (const [id, station] of this.stations) {
      data.stations.push(station.getMetrics());
    }
    
    const activeLogStations = this.logger.getActiveStations();
    for (const stationId of activeLogStations) {
      data.logs[stationId] = this.logger.getStats(stationId);
    }
    
    socket.emit('initialData', data);
  }

  broadcastMetrics() {
    const metrics = [];
    for (const [id, station] of this.stations) {
      if (station.isRunning) {
        metrics.push(station.getMetrics());
      }
    }
    
    if (metrics.length > 0) {
      this.io.emit('metricsUpdate', metrics);
    }
  }

  initializeStations() {
    // Load configuration
    const config = this.configLoader.load();
    
    console.log('[Dashboard] Initializing stations from config...');
    
    for (const [stationId, stationConfig] of Object.entries(config.buffer_stations)) {
      if (stationConfig.enabled !== false) {
        const station = new BaseStation(stationId, stationConfig, {
          monitor: this.monitor,
          logger: this.logger,
          recorder: this.recorder
        });
        
        this.stations.set(stationId, station);
        console.log('[Dashboard] Initialized station:', stationId);
      }
    }
    
    console.log('[Dashboard] Total stations initialized:', this.stations.size);
  }

  async start() {
    return new Promise((resolve) => {
      this.server.listen(this.port, () => {
        console.log('========================================');
        console.log('Audio Quality Monitoring Dashboard');
        console.log('========================================');
        console.log('Server running on port:', this.port);
        console.log('Dashboard URL: http://localhost:' + this.port);
        console.log('API Endpoints:');
        console.log('  GET  /api/stations          - All station metrics');
        console.log('  GET  /api/stations/:id      - Specific station');
        console.log('  GET  /api/logs              - LOG status');
        console.log('  GET  /api/recordings        - WAV files');
        console.log('  POST /api/stations/:id/log/:action');
        console.log('  POST /api/stations/:id/record/:action');
        console.log('========================================');
        console.log('');
        
        // Initialize stations
        this.initializeStations();
        
        // Start monitor service
        this.monitor.start();
        
        console.log('[Dashboard] Ready for connections');
        resolve();
      });
    });
  }

  async stop() {
    console.log('[Dashboard] Stopping server...');
    
    // Stop all stations
    for (const [id, station] of this.stations) {
      await station.stop();
    }
    
    // Cleanup modules
    await this.logger.cleanup();
    await this.recorder.cleanup();
    
    this.server.close();
    console.log('[Dashboard] Server stopped');
  }
}

// Main execution
if (require.main === module) {
  const dashboard = new DashboardServer(3020);
  
  dashboard.start().catch(error => {
    console.error('[Dashboard] Failed to start:', error);
    process.exit(1);
  });
  
  // Graceful shutdown
  process.on('SIGINT', async () => {
    console.log('\\n[Dashboard] Received SIGINT, shutting down gracefully...');
    await dashboard.stop();
    process.exit(0);
  });
  
  process.on('SIGTERM', async () => {
    console.log('\\n[Dashboard] Received SIGTERM, shutting down gracefully...');
    await dashboard.stop();
    process.exit(0);
  });
}

module.exports = DashboardServer;
